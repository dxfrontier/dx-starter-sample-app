sap.ui.define(['sap/fe/core/AppComponent'], function (Component) {
  'use strict';

  return Component.extend('poetryslams.Component', {
    metadata: {
      manifest: 'json'
    }
  });
});
